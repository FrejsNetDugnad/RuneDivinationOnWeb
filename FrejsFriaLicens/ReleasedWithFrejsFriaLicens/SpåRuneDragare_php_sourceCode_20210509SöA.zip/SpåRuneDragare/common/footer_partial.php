<!-- Footer -->
<footer class="rune-container-footer rune-align-center rune-font" style="font-size:18px!important">
    <br />
    <br />
    <div class="rune-info-left">
        <a href="../FrejsFriaLicens/FrejsFriaLicens_index.php">
            ©2021-
            <script>document.write(new Date().getFullYear())</script>
        </a>
        <div class="rune-info-right"><a href="../FrejsFriaLicens/FrejsFriaLicens_index.php">Frejs Fria Licens 2019</a></div>
    </div>
</footer>