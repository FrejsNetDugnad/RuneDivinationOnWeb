<?php namespace midgardskultur\php\DiscordRunDivinationBot\Config;
include "websocket.php";
class Config {
	public $bottoken = "";
	public $acl  = "";
	public $websocket   = "";
	public $retries   = 0;
	private $ini_array;
	
	  function __construct() {
		// parse ini file
		$this->ini_array = parse_ini_file("../settings/nebucord.ini");	
		$this->bottoken = $this->ini_array["bottoken"];
		$this->acl = $this->ini_array["acl"];
		$this->retries = $this->ini_array["websocket_retries"];
		$this->websocket = new websocket($this->retries );
		$this->websocket->set_retries($this->retries);
		
    }
}
?>
