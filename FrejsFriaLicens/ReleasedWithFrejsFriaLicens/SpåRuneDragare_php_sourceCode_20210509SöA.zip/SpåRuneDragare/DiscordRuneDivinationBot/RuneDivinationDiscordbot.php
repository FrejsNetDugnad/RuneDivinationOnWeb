<?php namespace  midgardskultur\php\DiscordRunDivinationBot;
include "../Nebucord/nebucord_autoloader.php";
include "../Runes/RuneSet.php";
include "Config.php";

use Nebucord\Nebucord;
use Runes as Runor;

class MessageInterceptorClass {
	
	// For testing
	public function get(){
		echo "Hello bot sed and sejd world!!";
		echo $this->DrawAndSendRunes(3);
	}
	
    public function onMessageReceive($evt) {
        // $evt is a model with all data from the gateway if a message create
        // event is received
		
		if(strpos($evt->content,"draw runes")!="FALSE"){
			echo $this->DrawAndSendRunes(3);
			return;
		} elseif(strpos($evt->content,"draw rune")!="FALSE"){
			echo $this->DrawAndSendRunes(1);
		}else{
			echo "Hello bot sed and sejd world!!";
		}
    }

	private function DrawAndSendRunes(int $numberOfRunesToDraw){
			
			$runeDrawer = new Runor\RuneSet();
			$runeDrawer->drawRunes($numberOfRunesToDraw);
	
			$divinationText = "Rune divination: "  + get_divination_text;
	
			return  divinationText; // returns the divination text message	;
		}
}
$config = new Config\Config();

$nebucordEventTable = \Nebucord\Events\Nebucord_EventTable::create();
$nebucordEventTable->addEvent(new MessageInterceptorClass, "onMessageReceive", \Nebucord\Base\Nebucord_Status::GWEVT_MESSAGE_CREATE);

$nebucord = new Nebucord(['token' =>$config->bottoken , 'ctrlusr' => $config->acl]);
$nebucord->bootstrap()
    ->setEventTable($nebucordEventTable)
    ->run();

$nebucord->bootstrap()
    ->setEventTable($onMessageReceive)
    ->run();
	
?>