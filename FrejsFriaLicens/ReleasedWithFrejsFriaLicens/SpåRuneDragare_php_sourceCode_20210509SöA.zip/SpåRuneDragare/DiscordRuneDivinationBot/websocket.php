<?php namespace midgardskultur\php\DiscordRunDivinationBot\Config;
class websocket{
	public $retries = 0;
	
	public function set_retries($retries) {
		$this->retries = $retries;
	}	
	public function get_retries() {
		return $this->retries;
	}
}
?>
