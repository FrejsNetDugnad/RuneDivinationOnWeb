<?php
// Old page. Only exists for backward compability. 20210504Ti.
?>
<script> location.replace("RuneDivination_se.php?runestodraw=1"); </script>