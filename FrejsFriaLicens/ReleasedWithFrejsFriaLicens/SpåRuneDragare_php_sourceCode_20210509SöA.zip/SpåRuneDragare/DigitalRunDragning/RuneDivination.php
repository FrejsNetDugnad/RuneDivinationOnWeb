<?php
// Old page. Only exists for backward compability. 20210508Lö.
header("Location: RuneDivination_se.php?runestodraw=1");
exit();
?>