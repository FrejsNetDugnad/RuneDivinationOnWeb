﻿<?php
// Old redirect to default language.
?>
<script> location.replace("index_se.php"); </script>