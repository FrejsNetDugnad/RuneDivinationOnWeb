﻿<?php
// New placeholder page. A place for future index to the rest of Frejs Fria Licens pages.
?>
<script> location.replace("FrejsFriaLicens_index.php"); </script>